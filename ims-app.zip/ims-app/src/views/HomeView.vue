<script setup lang="ts">
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useInventoryStore } from '@/stores/inventory/inventoryStore'
import type { InventoryItem } from '@/services/inventory/types'

const inventory = useInventoryStore()
const router = useRouter()

onMounted(async () => {
  await inventory.dispatchFetchItems()
})

const statusColor = (status: InventoryItem['status']) => {
  switch (status) {
    case 'in stock':
      return 'bg-green-100 text-green-700'
    case 'low stock':
      return 'bg-yellow-100 text-yellow-700'
    case 'ordered':
      return 'bg-blue-100 text-blue-700'
    case 'discontinued':
      return 'bg-gray-200 text-gray-500'
    default:
      return ''
  }
}
const viewItem = (id: string) => {
  // Route to edit page or open modal with item.id
  router.push({ name: 'inventory', params: { id } })
}
const editItem = (item: InventoryItem) => {
  // Route to edit page or open modal with item.id
  console.log('Edit', item)
}

const deleteItem = async (id: string) => {
  try {
    await inventory.dispatchDeleteItem(id)
  } catch (err: any) {
    console.error('Delete failed:', err.message)
  }
}
</script>

<template>
  <div class="flex mb-4">
    <button
      class="ml-auto text-white bg-indigo-500 border-0 py-2 px-6 rounded hover:bg-indigo-600"
      @click="router.push('/add')"
    >
      Add Item
    </button>
  </div>

  <div v-if="inventory.items.length === 0" class="text-gray-500 text-center py-6">
    No inventory items found.
  </div>

  <table v-else class="min-w-full divide-y divide-gray-200 border shadow rounded-md">
    <thead class="bg-gray-100">
      <tr>
        <th class="px-4 py-2 text-left text-sm font-semibold text-gray-600">Name</th>
        <th class="px-4 py-2 text-left text-sm font-semibold text-gray-600">Quantity</th>
        <th class="px-4 py-2 text-left text-sm font-semibold text-gray-600">Category</th>
        <th class="px-4 py-2 text-left text-sm font-semibold text-gray-600">Status</th>
        <th class="px-4 py-2 text-center text-sm font-semibold text-gray-600">Actions</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-gray-100 bg-white">
      <tr v-for="item in inventory.items" :key="item.id" class="hover:bg-gray-50">
        <td class="px-4 py-2">{{ item.name }}</td>
        <td class="px-4 py-2">{{ item.quantity }}</td>
        <td class="px-4 py-2">{{ item.category }}</td>
        <td class="px-4 py-2">
          <span
            :class="[
              'inline-block px-2 py-1 rounded text-xs font-medium',
              statusColor(item.status),
            ]"
          >
            {{ item.status }}
          </span>
        </td>
        <td class="px-4 py-2 text-center">
          <button @click="viewItem(item.id)" class="text-blue-600 hover:underline text-sm mr-3">
            view
          </button>
          <button @click="editItem(item)" class="text-blue-600 hover:underline text-sm mr-3">
            Edit
          </button>
          <button @click="deleteItem(item.id)" class="text-red-600 hover:underline text-sm">
            Delete
          </button>
        </td>
      </tr>
    </tbody>
  </table>
</template>
