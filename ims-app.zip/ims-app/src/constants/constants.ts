export const CONSTANTS = {
    API_BASE_URL: 'https://jsonplaceholder.typicode.com',
    API_TIMEOUT: 30000,
}