import { PostService } from './posts';

export const API = {
  posts: PostService
};
