<script setup lang="ts">
import AiChatBlock from '@/components/ui/AiChat.vue';
</script>

<template>
  <ai-chat-block />
</template>
